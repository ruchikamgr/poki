import React from 'react'

const PokemonContext = React.createContext({});

export default PokemonContext;